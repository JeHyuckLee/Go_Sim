## Contributing
All contributions are welcome :smile:, as long as they are clear, concise, commented and
well-tested. Feel free to open a pull request.
