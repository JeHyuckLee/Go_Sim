This code was copied from src/debug/gosym in the go repo at commit de95dca32fb196d5f09bf5db4a6ba592907559c3.

It was modified to remove dependencies on internal packages in the go repo,
and to compile under go 1.17.
