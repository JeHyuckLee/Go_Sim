package secret

func Hello() {}